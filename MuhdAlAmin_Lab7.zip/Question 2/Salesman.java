class Salesman extends Employee
{
   protected double basic_salary,sales_amount,comm_percentage;
   final double TAX_PERCENTAGE=0.15;
   
   public Salesman(String e_nam,String e_id,double b_per,double b_salary,double s_amt,double c_per)
   {
      super(e_nam,e_id,b_per);
      basic_salary=b_salary;
      sales_amount=s_amt;
      comm_percentage=c_per;
   }
   
   public double calcNetSalary()
   {
      double saleComm=sales_amount*comm_percentage;
      double totalBonus=(basic_salary + saleComm)* bonus_percentage;
      double totalTax=basic_salary*TAX_PERCENTAGE;
      double newSalary=basic_salary+totalBonus-totalTax;
      return newSalary;
   }
   
   public String toString()
   {
      return super.toString()+"\nBasic Salary :"+basic_salary+"\nSales Amount :"+sales_amount+"\nCommision percentage :"+comm_percentage+"\nNet Salary :"+calcNetSalary();
   }
}
