public class Client
{
   public static void main(String args[])
   {
      Salesman s_man=new Salesman("MUHAMMAD AL-AMIN","2018280578",0.05,5000.0,440.00,0.250);
      HourlyEmployee h_emp=new HourlyEmployee("MUHAMMAD ZAID","2019875265",0.05,6,35.00);
      
      System.out.println("\nEmployee Info :" +s_man.toString());
      System.out.println("\nEmployee Info :" +h_emp.toString());
   }
}