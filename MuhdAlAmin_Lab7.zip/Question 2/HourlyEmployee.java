class HourlyEmployee extends Employee
{
   protected int hours_work;
   protected double wage_per_hour;
   
   public HourlyEmployee(String e_nam,String e_id,double b_per,int hw,double wph)
   {
      super(e_nam,e_id,b_per);
      hours_work=hw;
      wage_per_hour=wph;
   }
   
   public double calcNetSalary()
   {
      double bonus=(hours_work*wage_per_hour)+super.bonus_percentage;
      double salary=(hours_work*wage_per_hour)+bonus;
      return salary;
   }
   
   public String toString()
   {
   return super.toString()+"\nhours Work :"+hours_work+"\nWage per hours :"+wage_per_hour+"\nNet Salary :"+calcNetSalary();
   }
   
}