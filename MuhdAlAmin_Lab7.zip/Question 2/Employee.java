class Employee
{
   protected String emp_name,emp_id;
   protected double bonus_percentage;

   public Employee(String e_nam,String e_id,double b_per)
   {
      emp_name=e_nam;
      emp_id=e_id;
      bonus_percentage=b_per;     
   }
   
   public String toString()
   {
      return("\nEmployee Name :"+emp_name+"\nEmployee ID :"+emp_id);
}
}