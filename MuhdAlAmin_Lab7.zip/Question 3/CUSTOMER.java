class CUSTOMER
{
   protected String name,customerCat;
   protected boolean member;
   
   public CUSTOMER(String nm,String cst,boolean mbr)
   {
      name=nm;
      customerCat=cst;
      member=mbr;
   }
   
   public String getName(){return name;}
   public String getCustomerCat(){return customerCat;}
   public boolean getMember(){return member;}
   
     
   
}
