import java.util.Scanner;
class CUSTOMERAPP
{
  public static void main(String args[])
   {
   VIP cust=new VIP("Siti","VIP",true,250.0,"B");
   REGULAR cust1=new REGULAR("Zaleha","Regular",true,150.0,"F");
   
   Scanner scan1=new Scanner(System.in);
   Scanner scan2=new Scanner(System.in);
   
  System.out.println("Enter number of customer :");
  int num=scan2.nextInt();
  
   CUSTOMER cust2[]=new CUSTOMER[num];
     
  
   for(int y=0;y<num;y++)
   {
   System.out.println("Enter Name :");
   String name=scan1.nextLine();
   System.out.println("Enter Customer Category (VIP / REGULAR) :");
   String customerCat=scan1.nextline();
   System.out.println("Enter member (Yes=true / no=false) :");   
   boolean member=scan2.nextBoolean();
   
   cust2[y]=new CUSTOMER(name,customerCat,member);


   if(customerCat.equalsIgnoreCase("VIP"))
   {
   System.out.println("Enter package price :");
   double price=scan2.nextDouble();
   System.out.println("(Scrubs & wraps (S)/ Body Massages(B) :");
   String vipService=scan1.nextLine();
   
   cust[y]=new VIP(name,customerCat,member,price,vipService);
   }
   else if(customerCat.equalsIgnoreCase("Regular"))
   {
   System.out.println("Enter package price :");
   double price=scan2.nextDouble();
   System.out.println("((Body Massages(B)/ Facial(F) :");
   String regularService=scan1.nextLine();
   
   cust1[y]=new REGULAR(name,customerCat,member,price,regularService);
   }
   }
   
   int count=0;
   for(int z=0;z<num;z++)
    { if(num[z].getCustomerCat().equalsIgnoreCase("VIP"))
      { 
      count++;
      }
    }
    
    System.out.println("\n VIP customer Info :"+cust.display());
    System.out.println("\nRegular customer Info :"+cust1.display());
    System.out.println("\nNumberVIP customers : "+count);
    
  }


}

:(