class REGULAR extends CUSTOMER
{
   protected double price;
   protected String regularService;
   
   public REGULAR(String nm,String cst,boolean mbr,double prc,String regser)
   {
      super("Anonymous","Regular",true);
      price=150.0;
      regularService="F";
   }
   
   public void setToAll(double prc,String regser)
   {
      price=prc;
      regularService=regser;
   }
   
   public double getPrice(){return price;}
   public String getRegularService(){return regularService;}
   
   double memP=0;
   public double calcService()
   {
      if(getMember()==true)
            memP=10;
      else
            memP=0;
            
      return(getPrice()-(getPrice()*0.10)-memP);
   }
     public String display()
     {
     return "Name: "+super.name+"\nCustomer category: "+super.customerCat+"\nMember status: "+super.member+"\nThe original price for service: "+price+"\nThe new price for service: "+calcService()+"\nType of service: "+regularService;
     }


}
