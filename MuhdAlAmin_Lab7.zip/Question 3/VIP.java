class VIP extends CUSTOMER
{
   protected double price;
   protected String vipService;
   
   public VIP(String nm,String cst,boolean mbr,double prc,String vser)
   {
      super(nm,cst,mbr);
      price=prc;
      vipService=vser;
   }
   
   public double getPrice(){return price;}
   public String getVipService(){return vipService;}
   
   double memP=0;
   public double calcNewPrice()
   {
      if(getMember()==true)
            memP=50;
      else
            memP=0;
            
      return(getPrice()-(getPrice()*0.15)-memP);
   }
      
     public String display()
     {
     return "Name: "+super.name+"\nCustomer category: "+super.customerCat+"\nMember status: "+super.member+"\nThe original price for service: "+price+"\nThe new price for service: "+calcNewPrice()+"\nType of service: "+vipService;
     }

}
