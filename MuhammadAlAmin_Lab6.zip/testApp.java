import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;

class testApp
{
   public static void main(String args[])
   {
      int p=0;
      int f=0;
      try
      {
         double totalMarks;
         FileReader fr=new FileReader("csc238.txt");
         BufferedReader br=new BufferedReader(fr);
         String strLine;
         
         FileWriter wr=new FileWriter("pass.txt");
         PrintWriter pass=new PrintWriter(wr);
         
         FileWriter wr1=new FileWriter("fail.txt");
         PrintWriter fail=new PrintWriter(wr1);
         
         double id;
         String nm;
         double qz,proj,lb,t1,t2,fexam;
         pass.printf("%-20s%-20s%-10s%-10s%-10s%-10s%-10s%-10s%-10s\n","UiTM ID","Name","Quiz","Lab","Project","Lab","Test1","Test2","Final Exam","Total Mark");
         fail.printf("%-20s%-20s%-10s%-10s%-10s%-10s%-10s%-10s%-10s\n","UiTM ID","Name","Quiz","Lab","Project","Lab","Test1","Test2","Final Exam","Total Mark");
         
         while((strLine=br.readLine())!=null)
         {
              StringTokenizer data= new StringTokenizer(strLine,";");
              id=Double.parseDouble(data.nextToken());
              nm=data.nextToken();
              qz=Double.parseDouble(data.nextToken());
              proj=Double.parseDouble(data.nextToken());
              lb=Double.parseDouble(data.nextToken());
              t1=Double.parseDouble(data.nextToken());
              t2=Double.parseDouble(data.nextToken());
              fexam=Double.parseDouble(data.nextToken());
              
              test std=new test(id,nm,qz,proj,lb,t1,t2,fexam);
              
              if(std.calcTotal()>=50)
              {
                  pass.printf("%-20.0f%-20s%-10.1f%-10.1f%-10.1f%-10.1f%-10.1f%-10.1f%-10.1f\n",id,nm,qz,lb,proj,t1,t2,fexam,std.calcTotal());
                  p++;
              }
              else if(std.calcTotal()<50)
              {
                  fail.printf("%-20.0f%-20s%-10.1f%-10.1f%-10.1f%-10.1f%-10.1f%-10.1f%-10.1f\n",id,nm,qz,lb,proj,t1,t2,fexam,std.calcTotal());
                  f++;
              }
         }
           
           pass.printf("***Number Of Record : "+p);
           fail.printf("***Number Of Record : "+f);
           br.close();
           pass.close();
           fail.close();
      }
       catch (Exception e)    
       {        
       System.err.println("Error: " + e.getMessage());    
       }
         
         
         
         
      }
   
}