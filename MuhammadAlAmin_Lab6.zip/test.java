public class test
{
   private double stuID,quiz,project,lab,test1,test2,finalexam;
   private String name;
   
   public test(double id,String nm,double qz,double proj,double lb,double t1,double t2,double fexam)
   {
      stuID=id;
      name=nm;
      quiz=qz;
      project=proj;
      lab=lb;
      test1=t1;
      test2=t2;
      finalexam=fexam;
   }
   
   public double getStuID(){return stuID;}
   public String getName(){return name;}
   public double getQuiz(){return quiz;}
   public double getProject(){return project;}
   public double getLab(){return lab;}
   public double getTest1(){return test1;}
   public double getTest2(){return test2;}
   public double getFinalexam(){return finalexam;}
   
   public double calcTotal()
   {
      double total=getQuiz()+getProject()+getLab()+getTest1()+getTest2()+getFinalexam();
      return total;
   } 
   
}